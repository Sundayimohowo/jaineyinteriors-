<?php

define("ROOT_PATH", realpath(dirname(__FILE__)));
define("BASE_URL","http://localhost/interior");
// define("BASE_URL","https://fid-press.com");
?>
