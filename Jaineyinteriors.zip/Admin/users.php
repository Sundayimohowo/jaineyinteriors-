<?php include 'header.php'; 
include 'sidebar.php'; 
$users=selectAll('users');?>

<div class='the-content'>
<h4>Users <a href='new-user.php'><button class="addnew">Add New</button></a></h4>

<div class="content-body">
<div class='table-content'>
<div class="table-heading">
	<span>USERNAME</span>
	<span>ROLE</span>
	<span>ACTION</span>
</div>
<?php 
 
foreach ($users as $key => $user) {
	?>
<div class="table-inputs">
	<h5><?php echo $user['username']; ?></h5>
	<h5><?php echo $user['role'] ?></h5>
	<form action='adminData.php' method='POST' id='myForm'>
		<input type='hidden' name='delete_user' value='<?php echo $user['id']; ?>'/><button class="delete">Remove</button></form>
</div>
<?php } ?>

</div>
	
</div>

</div>
</div>
<script>

		let toggleBar = document.querySelector('.toggle-bar');
		let navbox = document.querySelector('.sidebar-nav');
		let navStatus = false;
		toggleBar.addEventListener('click', slideToggle);

		function slideToggle() {
		
			if (navStatus == true) {
				navbox.style.left = "-660px";
				navStatus = false;
			} else if (navStatus == false) {
				navbox.style.left = "0";
				navStatus=true;
			}
			
		}

	</script>
</div>
</body>
</html>