<div class='sidebar-nav'>
<ul>
	<li class="active"><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a></li>
	<li class='nav-list'><a href='javascript:void(0);'><i class="fa fa-clipboard"></i>Posts<ul class='dropdown-ul'>
		<li><a href="posts.php">All Posts</a></li>
		<li><a href="add-post.php">Add New</a></li>
		<li><a href="categories.php">Categories</a></li>
	</ul></a></li>
	<!-- <li class='nav-list'><a href=""><i class="fas fa-briefcase"></i>Portolio<ul class='dropdown-ul'>
		<li><a href="portfolio.html">All Portfolio</a></li>
		<li><a href="">Add New</a></li>
	</ul></a></li> -->
	<li class='nav-list'><a href='javascript:void(0);'><i class="fas fa-user"></i>Users<ul class='dropdown-ul'>
		<li><a href="users.php">All Users</a></li>
		<li><a href="new-user.php">Add New</a></li>
	</ul></li>
    <li><i style='color:#fff;' class="fa fa-star"></i><a href='reviews.php'>Reviews</a></li>
	<li class='nav-list'><i style='color:#fff;' class="fa fa-image"></i><a href='javascript:void(0);'>Gallery</a><ul class='dropdown-ul'>
		<li><a href="gallery.php">Add New</a></li>
		<li><a href="gallery-category.php">Categories</a></li>
	</ul></li>
</ul>
</div>